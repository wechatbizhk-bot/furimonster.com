FURI MONSTER — sticker pack
===========================

Pack:   Colour-In Line Art (Pack 02)
Files:  6 PNG, transparent background
Source: https://furimonster.com/assets/downloads/furimonster-colour-in-pack-02.zip

LICENCE
-------
Free to use for personal, non-commercial purposes: chat apps, your own
social posts, your own devices. Please do not sell these files, republish
them as your own sticker pack, or use them in advertising or on merchandise.
Commercial use is licensed separately:
  https://furimonster.com/licensing.html

The characters belong to their creator. Offered as-is, with no warranty.

FURI MONSTER 貼圖 —— 個人非商業用途免費使用。請勿轉售、請勿當作自己的貼圖包
重新發布、請勿用於廣告或商品。商業用途請見上列授權頁。

https://furimonster.com/stickers.html